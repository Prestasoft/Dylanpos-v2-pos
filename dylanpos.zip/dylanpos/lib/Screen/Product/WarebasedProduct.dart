class WarehouseBasedProductModel {
  late String productName;
  late String productID;

  WarehouseBasedProductModel(
    this.productName,
    this.productID,
  );
}
